%% BYOM function derivatives.m (the model in ODEs)
%
%  Syntax: dX = derivatives(t,X,par,c)
%
% This function calculates the derivatives for the model system. It is
% linked to the script files <byom_debkiss_with_egg.html
% byom_debkiss_with_egg.m>. As input, it gets:
%
% * _t_   is the time point, provided by the ODE solver
% * _X_   is a vector with the previous value of the states
% * _par_ is the parameter structure
% * _c_   is the external concentration (or scenario number)
%
% Time _t_ and scenario name _c_ are handed over as single numbers by
% <call_deri.html call_deri.m> (you do not have to use them in this
% function). Output _dX_ (as vector) provides the differentials for each
% state at _t_.
%
% * Original BYOM/DEBkiss code author: Tjalling Jager
% * Date: April 2017
% * Web support: <http://www.debtox.info/byom.html>
% * Back to index <walkthrough_debkiss.html>

% * Author of DEBkiss Fundulus model code: Louise Stevenson
% * Date: May 2023
% *The model:* see Stevenson et al. "Connecting suborganismal data to bioenergetic processes: killifish embryos exposed to a dioxin-like compound"

%% Start

function dX = derivatives(t,X,par,c)

global glo          % allow for global parameters in structure glo

%% Unpack states
% The state variables enter this function in the vector _X_. Here, we give
% them a more handy name.
MV      = X(1); % state 1 is the structural body mass
ME      = X(2); % state 2 is the egg buffer of assimilates
Q       = X(3); % state 3 is the total mass of PCB within the egg (MV+ME)
DELTA   = X(4); % state 6 is the damage density in fish
S       = X(5); % state 7 is the survival of fish
%% Unpack parameters
% The parameters enter this function in the structure _par_. The names in
% the structure are the same as those defined in the byom script file.
% The 1 between parentheses is needed as each parameter has 5 associated
% values.

JAm_E  = par.JAm_E(1);  % specific assimilation rate 
JAm_L  = par.JAm_L(1);  % specific assimilation rate 
yVA  = par.yVA(1);  % specific assimilation rate 
kM0   = par.kM0(1);   % specific maintenance costs 
kap   = par.kap(1);   % allocation fraction to soma
f     = par.f(1);     % scaled food level
u   = par.u(1);       % 
k   = par.k(1);       % 
a   = par.a(1);       % 
h   = par.h(1);       % 
mu0   = par.mu0(1);       % 
rho   = par.rho(1);       % 
PHI   = par.PHI(1);       % 
GAMMA   = par.GAMMA(1);       % 

%% Calculate the derivatives
% This is the actual model, specified as a system of ODEs.

% The code below follows the model description in the SI as closely as
% possible but defines "model fuctions" before the derivatives because
% terms in the derivatives can't be used before they are defined. All
% derivatives are listed in the last part of the code.

%B: Toxicokinetic model functions
Cw0 = c;            %scenario name = PCB nominal exposure concentration

if t < 7             % PCB exposure for 7 days
    Cw = Cw0;        
else
    Cw = 0;          % moved to clean water at 7 days
end

Q_V = MV * Q / (MV + rho * ME);        % total PCB in fish

q_V = Q_V / MV;                    % PCBs in fish per unit fish biomass

%E: Toxicodynamic scaling model functions

% SUBLETHAL TOX EFFECT - effect on maitenance

kM = kM0 * (1 + GAMMA * DELTA);   % tox increasing mait

JM = kM * MV;                      % somatic maintenance

p = (kM0 * q_V^2) / (h^2 + q_V^2);  % damage production

r = a * DELTA / (k + DELTA);        % damage repair

%A: bioenergetic model functions

if ME > 1e-3                              % if an embryo... very small value so ME doesn't go negative, but this is basically 0
    JA = JAm_E * MV;                   % assimilation
else
    JA = JAm_L * MV * f;               % assimilation
end

if MV < (0.7 * 3.95e-5)                  % if mass is less than 70% of size at birth - we don't want to let mass get infinitely small
    JG = 0;
else
    JG = yVA * (kap * JA - JM);      % growth
end

% Calcululate the derivatives
dMV = JG;             % change in body mass

if ME > 1e-3             % for embryos ... very small value so ME doesn't go negative, but this is basically 0
    dME = -JA;        % decrease in egg buffer
else
    dME = 0;          % for juveniles/adults, no change
end

dQ = u * Cw;                        % uptake of PCBs from water

dDELTA = p - r - (DELTA / MV) * dMV;          % scaled damage

dS = - S * (mu0 + PHI * DELTA);

dX = [dMV; dME; dQ; dDELTA; dS];       % collect all derivatives in one vector
