%% BYOM, byom_debkiss_with_egg_Fundulus.m
%
% * Original BYOM/DEBkiss code author: Tjalling Jager
% * Date: April 2017
% * Web support: <http://www.debtox.info/byom.html>
% * Back to index <walkthrough_debkiss.html>

% * Author of DEBkiss Fundulus model code: Louise Stevenson
% * Date: May 2023
%
% BYOM is a General framework for simulating model systems in terms of
% ordinary differential equations (ODEs). The model itself needs to be
% specified in <derivatives.html derivatives.m>, and <call_deri.html
% call_deri.m> may need to be modified to the particular problem as well.
% The files in the engine directory are needed for fitting and plotting.
% Results are shown on screen but also saved to a log file (results.out).
%
% *The model:* see Stevenson et al. "Connecting suborganismal data to bioenergetic processes: killifish embryos exposed to a dioxin-like compound"
%

%% Initial things
% Make sure that this script is in a directory somewhere *below* the BYOM
% folder.

clear, clear global % clear the workspace and globals
global DATA W X0mat % make the data set and initial states global variables
global glo          % allow for global parameters in structure glo
global pri zvd      % global structures for optional priors and zero-variate data
diary off           % turn of the diary function (if it is accidentaly on)
set(0,'DefaultFigureWindowStyle','docked'); % collect all figure into one window with tab controls
% set(0,'DefaultFigureWindowStyle','normal'); % separate figure windows

pathdefine % set path to the BYOM/engine directory
glo.basenm  = mfilename; % remember the filename for THIS file for the plots
glo.saveplt = 0; % save all plots as (1) Matlab figures, (2) JPEG file or (3) PDF (see all_options.txt)

%% The data set
% Data are entered in matrix form, time in rows, scenarios (exposure
% concentrations) in columns. First column are the exposure times, first
% row are the concentrations or scenario numbers. The number in the top
% left of the matrix indicates how to calculate the likelihood:
%
% * -1 for multinomial likelihood (for survival data)
% * 0  for log-transform the data, then normal likelihood
% * 0.5 for square-root transform the data, then normal likelihood
% * 1  for no transformation of the data, then normal likelihood
%% for sensitive pops - data
%for sensitive
scen_names = [0 0.2 2 20 21 60 100 140 200 210 2000 2100 20000 200000]; %sensitive pops

num = importdata('avg_length_sensitivepops_mm.csv'); 
num.data = num.data(:,1:(length(num.data)-1)); %removing extra column I had to add so it would upload all data
n_timepts = size(num.data,1);
n_data =  size(num.data,2)-1;

DATA{1} = [1 scen_names; num.data]; %normal data loading

num_dateofhatch = importdata('avg_dayofhatch_sensitivepops.csv'); 
num_dateofhatch.data = num_dateofhatch.data(:,1:(length(num_dateofhatch.data)-1)); %removing extra column I had to add so it would upload all data
DATA{2} = [1 scen_names; num_dateofhatch.data]; %normal data loading

DATA{3} = 0; %no data on total toxicant load in egg

DATA{4} = 0; %no data on damage 

num_surv = importdata('avg_survival_sensitivepops.csv'); %
num_surv.data = num_surv.data(:,1:(length(num_surv.data)-1)); %removing extra column I had to add so it would upload all data
DATA{5} = [1 scen_names; num_surv.data]; %normal data loading

%% for tolerant pops - data
% % for tolerant
% scen_names = [0 2 20 200 210 2000 2100 20000 21000 200000 210000]; %tolerant pops
% 
% num = importdata('avg_length_tolerantpops_mm.csv'); %
% num.data = num.data(:,1:(length(num.data)-1)); %removing extra column I had to add so it would upload all data
% n_timepts = size(num.data,1);
% n_data =  size(num.data,2)-1;
% 
% DATA{1} = [1 scen_names; num.data]; %normal data loading
%         
% num_dateofhatch = importdata('avg_dayofhatch_tolerantpops.csv'); %
% num_dateofhatch.data = num_dateofhatch.data(:,1:(length(num_dateofhatch.data)-1)); %removing extra column I had to add so it would upload all data
% DATA{2} = [1 scen_names; num_dateofhatch.data]; %normal data loading
% 
% DATA{3} = 0; %no data on Q
% 
% DATA{4} = 0; %no data on damage
% 
% num_surv = importdata('avg_survival_tolerantpops.csv'); %
% num_surv.data = num_surv.data(:,1:(length(num_surv.data)-1)); %removing extra column I had to add so it would upload all data
% DATA{5} = [1 scen_names; num_surv.data]; 
% % 
% % % if weight factors are not specified, ones are assumed in start_calc.m
%% Initial values for the model parameters
% Model parameters are part of a 'structure' for easy reference. 
% Global parameters as part of the structure glo
  
glo.len   = 2;     % switch to fit physical length (0=off, 1=on, 2=on and no shrinking) (used in call_deri.m)
glo.mat   = 0;     % include maturity maint. (0=off, 1=include)
% Note: if glo.len > 0 than the initial state for size in X0mat is length too!

%pars for W-L relation, Knieb and Stiven 78
glo.c_LW = -6.18;
glo.b_LW = 3.29;

% syntax: par.name = [startvalue fit(0/1) minval maxval optional:log/normal scale (0/1)];
par.JAm_E = [0.91   0 0 1e6]; % specific assimilation rate embryos - best fit value with MV0 = 3e-1; prev fit value with yG = 1
par.JAm_L = [0.17   0 0.1 1e6]; % specific assimilation rate larvae - best fit value; prev fit value with yG = 1
par.kM0   = [0.023   0 0 1]; % specific maintenance costs - estimate from starvation including yG
par.ME0    = [1.41    0 0 1e6]; % initial weight of egg - Mvb + (Mvb * kM0 * t_b)/2
par.mu0     = [0.01  0 0 1]; % baseline mortality
par.yVA    = [1      0 0 1];   % yield of structure on assimilates (growth)

par.u       = [1.25e-4  0 0 1e6]; % uptake of PCB into fish; estimated from Diane Nacci's data
par.theta   = [9.02 	0 0 1e6]; % hill functional par relating damage prod to internal tox conc - from CYP1A data raw data; same for sens and tol

par.h       = [1.45e-2	0 0 1e6]; % SENSITIVE hill functional par relating damage prod to internal tox conc - from CYP1A data logged data; updated Feb 2022
% par.h       = [2.47	0 0 1e6]; % TOLERANT hill functional par relating damage prod to internal tox conc - from CYP1A data logged data; updated Feb 2022
par.rho     = [0.21     0 0 1e6]; %proportion of relative propensities for PCBs associating with yolk or biomass - fixed at value from Binder et al 1985

par.a       = [0.023     0 0 1e6 1]; % max specific damage repair rate
par.k       = [3.65e-8 0 0 1e6 1]; % SENSITIVE half saturation constant for repair
% par.k       = [5.28e-9 0 0 1e6 1]; % TOLERANT half saturation constant for repair
par.GAMMA   = [9.64e4    0 0 1e6 1]; % prop constant relating toxicant conc to effect on somatic mait
par.PHI     = [5185      0 0 1e6 1]; % prop constant relating damage density to survival

par.kap  = [0.8     0 0 1];   % allocation fraction to soma
par.f    = [1       0 0 1];   % scaled food leve
%% Initial values for the state variables
% Initial states, scenarios in columns, states in rows. First row are the
% 'names' of all scenarios.

X0mat = [scen_names                         % the scenarios
         repmat(3e-1, 1, n_data)            % initial length in mm - avg length at hatch is 6.8 for all controls
         repmat(par.ME0(1), 1, n_data)      % initail egg buffer
         zeros(1, n_data)                   % initial total mass of PCB in MV+ME
         zeros(1, n_data)                   % initial SCALED damage density 
         ones(1, n_data)];                  % initial survival  

% turning various treatments on and off
% Sensitive scenarios: 1-ACE (control); 2-0.2; 3-2; 4-20; 5-21; 6-60; 7-100; 8-140; 9-200; 10-210; 11-2000; 12-2100; 13-20000; 14-200000
% Tolerant scenaiors: 1-Control; 2-2; 3-20; 4-200; 5-210; 6-2000; 7-2100; 8-20000; 9-21000; 10-200000; 11-210000]; %tolerant pops
% X0mat(:, [4 6 7 8 9 11 13 14])    = []; %only treatments with growth data
% X0mat(:, [2 3 4 5 6 7 8 9 10 11 13 14]) = []; %only highest growth concs + control
% X0mat(:, [4 6 8 12:14]) = []; %treatments with growth data and highest for surv
% X0mat(:, [2 5 10 12]) = []; %focus on survival data
X0mat(:, [2:n_data]) = []; %just control

%% More options for the analysis
% Optionally, global parameters can be used in the structure glo (not
% fitted). However, see the text file reserved_globals.txt for names to
% avoid.

% % specify globals for parameters that are never fitted
% glo.Ct = 5; % the threshold could be made into a fixed global (also modify derivatives.m)
% % Special globals to modify the optimisation (used in transfer.m)
% glo.wts = [1 10];  % different weights for different data sets (same size as DATA)
% glo.var = [10 20]; % supply residual variance for each data set, after transformation (same size as DATA)

%% Zero-variate data and priors for Bayesian analyses
% Optionally, zero-variate data can be included. The corresponding model
% value needs to be calculated in call_deri.m, so modify that file too! You
% can make up your own parameter names in the structure _zvd_. Optionally,
% prior distributions can be specified for parameters, see the file
% calc_prior.m for the definition of the distributions. You must use the
% exact same names for the prior parameters as used in the _par_ structure.
% If you do not specify _zvd_ and/or _pri_ in your scripts, these options
% are simply not used in the analysis.
 
% zvd.ku = [10 0.5]; % example zero-variate data point for uptake rate, with normal s.d.
 
% First element in pri is the choice of distribution.
% pri.Piw   = [2 116 121 118]; % triangular, min, max and center
% pri.ke    = [3 0.2 0.1];     % normal with mean 0.2 and sd 0.1
% If no prior is defined, the min-max bounds will define a uniform one.
% Note that the prior is always defined on normal scale, also when the
% parameter will be fitted on log scale.
%% Time vector and labels for plots
% Specify what to plot. If time vector glo.t is not specified, a default is
% used, based on the data set
glo.t   = linspace(0,25,250); % time vector for the model curves in days
% glo.t   = linspace(0,5,50); % time vector for the model curves in days
% glo.t   = linspace(0,3,30); % time vector for the model curves in days

% specify the y-axis labels for each state variable
glo.ylab{1} = 'length (mm)';
glo.ylab{2} = 'egg buffer (mg)';
glo.ylab{3} = 'Total mass of PCB in egg';
glo.ylab{4} = 'scaled damage';
glo.ylab{5} = 'Survival (proportion surviving)';

% specify the x-axis label (same for all states)
glo.xlab    = 'time (days)';
glo.leglab1 = ''; % legend label before the 'scenario' number
glo.leglab2 = 'ng/L'; % legend label after the 'scenario' number

prelim_checks % script to perform some preliminary checks and set things up
% Note: prelim_checks also fills all the options (opt_...) with defauls, so
% modify options after this call, if needed.

%% Calculations and plotting
% Here, the functions are called that will do the calculation and the
% plotting. Note that calc_plot can provide all of the plotting information
% as output, so you can also make your own customised plots. This section,
% by default, makes a multiplot with all state variables (each in its own
% panel of the multiplot). When the model is fitted to data, output is
% provided on the screen (and added to the log-file results.out). The
% zero-variate data point is also plotted with its prediction (although the
% legend obscures it here).
%
% Options for the plotting can be set using opt_plot (see prelim_checks.m).
% Options for the optimisation routine can be set using opt_optim. Options
% for the ODE solver are part of the global glo.
%
% You can turn on the events function there too, to smoothly catch the
% discontinuity in the model. For the demo, the iterations were turned off
% (opt_optim.it = 0).

glo.eventson   = 0; % events function on (1) or off (0)
opt_optim.it   = 1; % show iterations of the optimisation (1, default) or not (0)
opt_plot.annot = 1; % extra subplot in multiplot for fits: 1) box with parameter estimates, 2) overall legend

% optimise and plot (fitted parameters in par_out)
par_out = calc_optim(par,opt_optim); % start the optimisation
calc_and_plot(par_out,opt_plot); % calculate model lines and plot them

% save_plot(gcf,'fit_example',[],3) % save active figure as PDF (see save_plot for more options)

%% Local sensitivity analysis
% Local sensitivity analysis of the model. All model parameters are
% increased one-by-one by a small percentage. The sensitivity score is
% by default scaled (dX/X p/dp) or alternatively absolute (dX p/dp).
%
% Options for the sensitivity can be set using opt_sense (see
% prelim_checks.m).
 
% % UNCOMMENT LINE(S) TO CALCULATE
% opt_sens.state = 2; % vector with state variables for the sensitivity analysis (0 does all, if sens>0)
% calc_localsens(par_out,opt_sens)

%% Asymptotic standard errors
% Here, asymptotic standard errors are calculated from the curvature of the
% likelihood function in the best estimate. This involves a numerical
% method that is not very robust, and therefore, I do _not_ recommend using
% this function (the two procedure below are far superior). However, it is
% a quick and dirty way to learn something about parameter uncertainty and
% correlations. The 'asymptotic' implies that these standard errors become
% more appropriate when the number of data points increases. (note: for
% this particular example, the calculation just fails).
%
% Options for the standard error can be set using opt_ase (see
% prelim_checks.m).
 
% % UNCOMMENT LINE(S) TO CALCULATE
% calc_ase(par_out,opt_ase) % uncomment this line to calculate ase's
% 
%% Profiling the likelihood
% By profiling you make robust confidence intervals for one or more of your
% parameters. Use the name of the parameter as it occurs in your parameter
% structure _par_ above. You do not need to run the entire script before
% you can make a profile. 
%
% Notes: profiling for complex models is a slow process, so grab a coffee!
% If the profile finds a better solution, it immediately saves it to the
% log file profiles_newopt.out. You can break of the analysis by pressing
% ctrl-c anytime, and use the values from the log file to restart (copy the
% better values into your _par_ structure).
%
% Options for the profiling can be set using opt_prof (see
% prelim_checks.m).

opt_prof.detail   = 1; % detailed (1) or a coarse (2) calculation
opt_prof.subopt   = 10; % number of sub-optimisations to perform to increase robustness
%  
% % UNCOMMENT LINE(S) TO CALCULATE
% % run a profile for selected parameters ... 
% calc_proflik(par_out,'JAm_E0',opt_prof);  % uncomment to calculate a profile
% calc_proflik(par_out,'sJrAm_L0',opt_prof); % uncomment to calculate a profile
% calc_proflik(par_out,'kM0',opt_prof);  % uncomment to calculate a profile
% calc_proflik(par_out,'ME0',opt_prof); % uncomment to calculate a profile

% calc_proflik(par_out,'A_prime',opt_prof);  % uncomment to calculate a profile
% calc_proflik(par_out,'K_prime',opt_prof); % uncomment to calculate a profile
% calc_proflik(par_out,'GAMMA',opt_prof);  % uncomment to calculate a profile
% calc_proflik(par_out,'phi_prime',opt_prof); % uncomment to calculate a profile

% UNCOMMENT LINE(S) TO CALCULATE
% Automatically calculate profiles for all parameters, and redo
% optimisation when a better value is found.
% opt_prof.subopt   = -1; % number of sub-optimisations to perform to increase robustness
% Note: a -1 makes a comparison between 0 and 10 sub-optimisations, and a
% -2 compares 0 suboptimisations and additional optimisation with simulated
% annealing. In this example, sub-optimisations are not needed. Note that
% the profile for Piw is cut off due to the triangular prior distribution.
% par_out = auto_profiles(par_out,opt_prof,opt_optim);

%% Slice sampler
% The slice sampler can be used for a Bayesian analysis as it provides a
% sample from the posterior distribution. A .mat file is saved which
% contains the sample, to use later for e.g., intervals on model
% predictions. The output includes the Markov chain and marginal
% distributions for each fitted parameter. The function calc_conf can be
% used to put confidence intervals on the model lines. 
%
% Notes: MCMC is also slow process for complex models, so consider another
% coffee! If a prior is specified, it is plotted in the marginal posterior
% plot as a red distribution. Two types of credible intervals are
% generated:
%
% # Highest probability regions. This captures the 95% of the parameter
% values with the highest posterior probability. it is calculated by
% lowering the horizotal dotted line in the figures for each parameters,
% until the area between the cut-off points captures 95% of the density.
% This can lead to unequal probabilities in the tails.
% # Quantiles. The region between the 2.5 and 97.5% quantiles is taken.
% This leads to 2.5% probability in each tail. This is shown in the plots
% by the broken vertical lines.
% 
% Options for the slice sampling can be set using opt_slice (see
% prelim_checks.m). Options for confidence bounds on model curves can be
% set in opt_conf (see prelim_checks).
% 
% Taking on parameters on log scale helps, as the slice sampler seems quite
% bad at obtaining a representative sample when the parameters have very
% different ranges. Thinning will be needed to reduce the autocorrelation
% (which is too much here). Note the plot that is produced with details of
% the sample!

% % UNCOMMENT LINE(S) TO CALCULATE
% opt_slice.thin     = 0; % thinning of the sample (keep one in every 'thin' samples)
% opt_slice.burn     = 100; % number of burn-in samples (0 is no burn in)
% opt_slice.alllog   = 1; % set to 1 to put all parameters on log-scale before taking the sample
% calc_slice(par_out,1000,opt_slice); % second argument number of samples (-1 to re-use saved sample from previous runs)

%% Likelihood region
% Another way to make intervals on model predictions is to use a sample of
% parameter sets taken from the joint likelihood-based conf. region. This
% is done by the function calc_likregion.m. It first does profiling of all
% fitted parameters to find the edges of the region. Then, Latin-Hypercube
% sampling, keeping only those parameter combinations that are not rejected
% at the 95% level in a lik.-rat. test. The inner rim will be used for CIs
% on forward predictions.
%
% Options for the likelihood region can be set using opt_likreg (see
% prelim_checks.m). 

% % UNCOMMENT LINE(S) TO CALCULATE
% opt_likreg.detail   = 1; % detailed (1) or a coarse (2) calculation
% opt_likreg.subopt   = 10; % number of sub-optimisations to perform to increase robustness
% opt_likreg.skipprof = 0; % skip profiling (and use profile from a saved mat file)
% calc_likregion(par_out,500,opt_likreg); % second argument is target for number of samples in inner region (-1 to re-use saved sample from previous runs)
% 
%% Plot results with confidence intervals
% The following code can be used to make a standard plot (the same as for
% the fits), but with confidence intervals (and sampling error for survival
% data, if needed). Options for confidence bounds on model curves can be
% set using opt_conf (see prelim_checks).
% 
% Use opt_conf.type to tell calc_conf which sample to use: 
% 1) Bayesian MCMC sample (default); CI on predictions are 95% ranges on 
% the model curves from the sample 
% 2) parameter sets from a joint likelihood region (limited sets can be 
% used), which will yield (asymptotically) 95% CIs on predictions

% % UNCOMMENT LINE(S) TO CALCULATE
% opt_conf.type    = 2; % use the values from the slice sampler (1) or likelihood region (2) to make intervals
% opt_conf.lim_set = 2; % for lik-region sample: use limited set of n_lim points (1) or outer hull (2) to create CIs
% opt_conf.sens    = 0; % type of analysis 0) no sensitivities 1) corr. with state, 2) corr. with state/control, 3) corr. with relative change of state over time
% 
% out_conf = calc_conf(par_out,opt_conf); % calculate confidence intervals on model curves
% calc_and_plot(par_out,opt_plot,out_conf); % call the plotting routine again to plot fits with CIs

%% Other files: derivatives
% To archive analyses, publishing them with Matlab is convenient. To keep
% track of what was done, the file derivatives.m can be included in the
% published result.
% 
% <include>derivatives.m</include>

%% Other files: call_deri
% To archive analyses, publishing them with Matlab is convenient. To keep
% track of what was done, the file call_deri.m can be included in the
% published result.
%
% <include>call_deri.m</include>

