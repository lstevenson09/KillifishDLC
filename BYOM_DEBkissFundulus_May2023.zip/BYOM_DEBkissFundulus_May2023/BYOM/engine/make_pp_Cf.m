function make_pp_Cf(Cf,makeplot)

% Usage: make_pp(Cf,makeplot)
%
% Creates a piecewise polynomial (pp) from of the forcing function in Cf.
% When makeplot=1, a plot is made to view the splines.

% Author     : Tjalling Jager 
% Date       : April 2017
% Web support: http://www.debtox.info/byom.html

global glo % the pp_coll_Cf and pp_scen_Cf are now part of the general global structure glo

% if they are already defined, extract pp_coll_Cf and pp_scen_Cf from glo
if isfield(glo,'pp_coll_Cf')
    pp_coll_Cf = glo.pp_coll_Cf;
    pp_scen_Cf = glo.pp_scen_Cf;
else % otherwise, define as empty
    pp_coll_Cf = [];
    pp_scen_Cf = [];
end

% have to catch cases were glo may not be completely defined when calling make_pp
if isfield(glo,'basenm') 
    filenm = glo.basenm; % for saving a plot, use the base filename
else
    filenm = 'exposure'; % but if not defined, use a default
end

scen   = Cf(1,2:end); % scenarios in this call

if length(unique(scen)) ~= length(scen) % more splines per scenario requested
    error('You entered multiple columns for the same scenario. Check your script, and use only one spline per scenario.')
end

if ~isempty(pp_coll_Cf) % it might have been already defined
    if sum(ismember(pp_scen_Cf,scen))>0
        error('Some scenarios already have a splined set. Check your script, and use only one spline per scenario.')
    end
    l_old = length(pp_scen_Cf); % length of old vector
    pp_scen_Cf = [pp_scen_Cf scen]; % add to the existing range
else
    l_old = 0;
    pp_scen_Cf = scen; % remember scenarios in first entry of cell array
end

if exist('griddedInterpolant','file') == 2 
    % newer versions of Matlab have different way of making interpolation then pp
    for i = l_old+1:l_old+length(scen) % run through scenarios
        pp_coll_Cf{i} = griddedInterpolant(Cf(2:end,1),Cf(2:end,i+1-l_old),'pchip','nearest'); % cubic hermite
        %     pp_coll_Cf{i} = griddedInterpolant(Cf(2:end,1),Cf(2:end,i+1-l_old),'linear','nearest'); % linear
    end
else % use the old version ... This possibility will be removed in the future
    for i = l_old+1:l_old+length(scen) % run through scenarios
        pp_coll_Cf{i} = interp1(Cf(2:end,1),Cf(2:end,i+1-l_old),'pchip','pp'); % cubic hermite
        %     pp_coll_Cf{i} = interp1(Cf(2:end,1),Cf(2:end,i+1-l_old),'linear','pp'); % linear
    end
end

if makeplot == 1 % only make a plot if asked to
        
    T = Cf(2:end,1); % time vector in data set
    t = linspace(min(T),max(T),200); % model vector
    
    % make one plot with subplots for each state variable
    n = ceil(sqrt(length(scen)));
    m = ceil(length(scen)/n);
    
    figh = make_fig(m,n); % make figure of correct size
    
    for i = l_old+1:l_old+length(scen) % run through scenarios
        subplot(m,n,i-l_old)
        set(gca,'LineWidth',1,'FontSize',12) % adapt axis formatting
        
        hold on
        
        if exist('griddedInterpolant','file') == 2 % for newer Matlab versions
            c = pp_coll_Cf{i}(t);
        else
            c = ppval(pp_coll_Cf{i},t); % use the pp form already provided
        end
        
        plot(t,c,'k-','LineWidth',2)
        plot(T,Cf(2:end,1+i-l_old),'ko','MarkerFaceColor','w','LineWidth',2)
        xlabel('time','FontSize',12)
        ylabel(['forcing, scenario ',num2str(pp_scen_Cf(i))],'FontSize',12)
        ylim([0 1.02*max(max(Cf(2:end,2:end)))])
        
    end
    
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping','off');
    h_txt = text(0.5, 1,'Splined points','HorizontalAlignment','center','VerticalAlignment', 'top');
    
    % note that plot is not saved is make_pp is called before defining glo.saveplt
    if isfield(glo,'saveplt') && glo.saveplt > 0 % if we want to save the plot
        savenm = ['spline_',filenm];%
        save_plot(figh,savenm,h_txt);
    end
    
end  

drawnow

% put the pp_coll_Cf and pp_scen_Cf back into the global glo
glo.pp_coll_Cf = pp_coll_Cf;
glo.pp_scen_Cf = pp_scen_Cf;

% % TEST TEST can we speed things up by making a table already here?
% TSpl = (linspace(min(t),max(t),200))';
% glo.tc_tab = [0 pp_scen_Cf ; TSpl zeros(length(TSpl),length(pp_scen_Cf))];
% for i = 1:length(pp_scen_Cf)
%     if exist('griddedInterpolant','file') == 2 % for new versions of Matlab
%         glo.tc_tab(2:end,1+i) = pp_coll_Cf{i}(TSpl); % use the pp form already provided
%     else
%         glo.tc_tab(2:end,1+i) = ppval(pp_coll_Cf{i},TSpl); % use the pp form already provided
%     end
% end

