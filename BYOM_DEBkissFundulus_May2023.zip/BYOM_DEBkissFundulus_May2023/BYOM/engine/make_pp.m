function make_pp(Cw,makeplot)

% Usage: make_pp(Cw,makeplot)
%
% Creates a piecewise polynomial (pp) from of the forcing function in Cw.
% When makeplot=1, a plot is made to view the splines.

% Author     : Tjalling Jager 
% Date       : April 2017
% Web support: http://www.debtox.info/byom.html

global glo % the pp_coll and pp_scen are now part of the general global structure glo

% if they are already defined, extract pp_coll and pp_scen from glo
if isfield(glo,'pp_coll')
    pp_coll = glo.pp_coll;
    pp_scen = glo.pp_scen;
else % otherwise, define as empty
    pp_coll = [];
    pp_scen = [];
end

% have to catch cases were glo may not be completely defined when calling make_pp
if isfield(glo,'basenm') 
    filenm = glo.basenm; % for saving a plot, use the base filename
else
    filenm = 'exposure'; % but if not defined, use a default
end

scen   = Cw(1,2:end); % scenarios in this call

if length(unique(scen)) ~= length(scen) % more splines per scenario requested
    error('You entered multiple columns for the same scenario. Check your script, and use only one spline per scenario.')
end

if ~isempty(pp_coll) % it might have been already defined
    if sum(ismember(pp_scen,scen))>0
        error('Some scenarios already have a splined set. Check your script, and use only one spline per scenario.')
    end
    l_old = length(pp_scen); % length of old vector
    pp_scen = [pp_scen scen]; % add to the existing range
else
    l_old = 0;
    pp_scen = scen; % remember scenarios in first entry of cell array
end

if exist('griddedInterpolant','file') == 2 
    % newer versions of Matlab have different way of making interpolation then pp
    for i = l_old+1:l_old+length(scen) % run through scenarios
        pp_coll{i} = griddedInterpolant(Cw(2:end,1),Cw(2:end,i+1-l_old),'pchip','nearest'); % cubic hermite
        %     pp_coll{i} = griddedInterpolant(Cw(2:end,1),Cw(2:end,i+1-l_old),'linear','nearest'); % linear
    end
else % use the old version ... This possibility will be removed in the future
    for i = l_old+1:l_old+length(scen) % run through scenarios
        pp_coll{i} = interp1(Cw(2:end,1),Cw(2:end,i+1-l_old),'pchip','pp'); % cubic hermite
        %     pp_coll{i} = interp1(Cw(2:end,1),Cw(2:end,i+1-l_old),'linear','pp'); % linear
    end
end

if makeplot == 1 % only make a plot if asked to
        
    T = Cw(2:end,1); % time vector in data set
    t = linspace(min(T),max(T),200); % model vector
    
    % make one plot with subplots for each state variable
    n = ceil(sqrt(length(scen)));
    m = ceil(length(scen)/n);
    
    figh = make_fig(m,n); % make figure of correct size
    
    for i = l_old+1:l_old+length(scen) % run through scenarios
        subplot(m,n,i-l_old)
        set(gca,'LineWidth',1,'FontSize',12) % adapt axis formatting
        
        hold on
        
        if exist('griddedInterpolant','file') == 2 % for newer Matlab versions
            c = pp_coll{i}(t);
        else
            c = ppval(pp_coll{i},t); % use the pp form already provided
        end
        
        plot(t,c,'k-','LineWidth',2)
        plot(T,Cw(2:end,1+i-l_old),'ko','MarkerFaceColor','w','LineWidth',2)
        xlabel('time','FontSize',12)
        ylabel(['forcing, scenario ',num2str(pp_scen(i))],'FontSize',12)
        ylim([0 1.02*max(max(Cw(2:end,2:end)))])
        
    end
    
    ha = axes('Position',[0 0 1 1],'Xlim',[0 1],'Ylim',[0 1],'Box','off','Visible','off','Units','normalized', 'clipping','off');
    h_txt = text(0.5, 1,'Splined points','HorizontalAlignment','center','VerticalAlignment', 'top');
    
    % note that plot is not saved is make_pp is called before defining glo.saveplt
    if isfield(glo,'saveplt') && glo.saveplt > 0 % if we want to save the plot
        savenm = ['spline_',filenm];%
        save_plot(figh,savenm,h_txt);
    end
    
end  

drawnow

% put the pp_coll and pp_scen back into the global glo
glo.pp_coll = pp_coll;
glo.pp_scen = pp_scen;

% % TEST TEST can we speed things up by making a table already here?
% TSpl = (linspace(min(t),max(t),200))';
% glo.tc_tab = [0 pp_scen ; TSpl zeros(length(TSpl),length(pp_scen))];
% for i = 1:length(pp_scen)
%     if exist('griddedInterpolant','file') == 2 % for new versions of Matlab
%         glo.tc_tab(2:end,1+i) = pp_coll{i}(TSpl); % use the pp form already provided
%     else
%         glo.tc_tab(2:end,1+i) = ppval(pp_coll{i},TSpl); % use the pp form already provided
%     end
% end

